![Pag AddRecord](AddRecord.png)

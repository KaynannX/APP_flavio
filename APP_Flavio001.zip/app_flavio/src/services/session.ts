interface Session {
    authenticated: boolean,
    id: string,
    email: string,
  }